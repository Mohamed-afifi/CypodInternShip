from email import message
import json
from numbers import Number
from operator import truediv
from flask import Flask, jsonify, request
import flask


app = Flask(__name__)



database=[]

@app.route('/books',methods=['GET'])
def get_books():
    return flask.jsonify(database)



def create_ID():
    return (len(database)+50)

@app.route('/books',methods=['POST'])
def add_books():
    if request.data:
        ID=create_ID()
        params=request.get_json()
        name=params['name']
        ISBN= params['isbn']
        #temp_dect={"id":ID,"Book Name":name,"ISBN":ISBN}
        database.append({"id":ID,"Book Name":name,"ISBN":ISBN})
        return flask.jsonify(status= "success",status_code= "200",id=ID)
    else:
        return flask.jsonify(status= "failed",status_code= "404",message="empty request")



@app.route('/books',methods=['DELETE'])    
def delete_books():
    global database
    params=request.get_json()

    given_id=int(params["ID"])
    
    first_len=len(database)
    res=list(filter(lambda x: x['id'] != given_id, database))
    database=res[:]
    second_len=len(database)

    
    if first_len!=second_len:
        return flask.jsonify(status= "success",status_code= "200",message="book id "+str(given_id)+" deleted succesfully")
    else:
        return flask.jsonify(status= "failed",status_code= "401",message="book id does not exist")
            



if __name__ == "__main__":
  app.run()

